package pages;

import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.android.AndroidDriver;
import utilities.FetchExcel;
import wrapper.CommonClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/***
 * @author Namitha
 */
public class HomePage extends CommonClass {
    private static Properties prop;
    AndroidDriver driver;
    private final String path = "//locators/HomePage.properties";

    FetchExcel excelData = new FetchExcel();

    /***
     * constructor to initiate driver and reports
     * @param ldriver - initiate driver
     * @param lTest - initiate report
     */
    public HomePage(AndroidDriver ldriver, ExtentTest lTest) {
        this.driver = ldriver;
        this.test = lTest;
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Enter product in search bar
     */
    private void enterProductToSearch() {
        elementClick(prop.getProperty("enter_text_to_search"),"Search");
        enterText(prop.getProperty("enter_text_to_search"), excelData.readData());
        //enterText(prop.getProperty("enter_search"), excelData.readData());
        //enterText(prop.getProperty("enter_text_to_search"),"Mobile");
        // enterTextJavascript(prop.getProperty("enter_text_to_search"),excelData.readData());
    }

    /**
     * Select random product from search list
     */
    private void selectProductFromSearchList() {
        generateAndClickRandom(prop.getProperty("search_Product"), "Random Product selected from search list");
    }

    /**
     * Select random product
     */
    private void selectProduct() {
        generateAndClickRandom(prop.getProperty("product_List"), "Random product selected");
    }

    /**
     * Search and select product
     */
    public void searchAndSelectProduct() {
        enterProductToSearch();
        selectProductFromSearchList();
        selectProduct();
    }
}
