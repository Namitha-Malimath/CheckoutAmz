package pages;

import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.android.AndroidDriver;
import wrapper.CommonClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author Namitha
 */
public class LocationDetailPage extends CommonClass {

    private static Properties prop;

    AndroidDriver driver;
    private final String path = "//locators/LocationDetailPage.properties";

    /***
     * constructor to initiate driver and reports
     * @param ldriver - initiate driver
     * @param lTest - initiate report
     */
    public LocationDetailPage(AndroidDriver ldriver, ExtentTest lTest) {
        this.driver = ldriver;
        this.test = lTest;
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /***
     * Validate Location Detail Page
     */
    private void validateLocationSettings() {
        //waitForElementClickable(prop.getProperty("use_My_Current_location"));
        waitForElement();
        if (verifyElement(prop.getProperty("use_My_Current_location"))) {
            verifyElementDisplayed(prop.getProperty("use_My_Current_location"), "Use my Current location");
            click_Enter_Pincode();
            Enter_Pincode();
        }
    }

    /**
     * click on Use my current location
     */
    private void clickUseMyCurrentLocation() {
        elementClick(prop.getProperty("use_My_Current_location"), "Use my Current location");
    }

    /**
     * click on Enter Pincode
     */
    private void click_Enter_Pincode() {
        elementClick(prop.getProperty("button_Enter_Pincode"), "Enter Pincode button");
    }

    /**
     * Enter Pincode
     */
    private void Enter_Pincode() {
        waitForElementClickable(getLocator(prop.getProperty("button_Enter_Pincode_Apply")));
        elementClick(prop.getProperty("text_Enter_Pincode"),"Text box to enter pincode");
        enterText(prop.getProperty("text_Enter_Pincode"), "560096");
        elementClick(prop.getProperty("button_Enter_Pincode_Apply"), "Apply button");
    }

    /**
     * validate location settings
     */
    public void location_details() {
        validateLocationSettings();
    }
}
