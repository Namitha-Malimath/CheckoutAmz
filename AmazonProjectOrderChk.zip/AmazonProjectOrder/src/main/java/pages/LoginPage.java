package pages;

import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.android.AndroidDriver;
import wrapper.CommonClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author Namitha
 */
public class LoginPage extends CommonClass {
    private static Properties prop;

    AndroidDriver driver;
    private final String path = "//locators/LoginPage.properties";

    /***
     * constructor to initiate driver and reports
     * @param ldriver - initiate driver
     * @param lTest - initiate report
     */
    public LoginPage(AndroidDriver ldriver, ExtentTest lTest) {
        this.driver = ldriver;
        this.test = lTest;
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Validate Amazon Sign In screen
     */
    private void validateAmazonSignInScreen() {
        verifyElementDisplayed(prop.getProperty("amazon_Sign_in"), "Amazon Sign In");
    }

    /**
     * Click on Skip Login
     */
    private void clickOnSkipLogin() {
        elementClick(prop.getProperty("amazon_skip_sign_in"), "Skip Sign In button");
    }

    /***
     * Validate amazon login screen and skip sign in screen
     */
    public void validateAndSelectSkipLogin() {
        validateAmazonSignInScreen();
        clickOnSkipLogin();
    }
}
