package pages;

import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.android.AndroidDriver;
import wrapper.CommonClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author Namitha
 */
public class ProductDetailsPage extends CommonClass {

    private static Properties prop;

    AndroidDriver driver;
    private final String path = "//locators/ProductDetailPage.properties";

    /***
     * constructor to initiate driver and reports
     * @param ldriver - initiate driver
     * @param lTest - initiate report
     */
    public ProductDetailsPage(AndroidDriver ldriver, ExtentTest lTest) {
        this.driver = ldriver;
        this.test = lTest;
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /***
     * Validate Product Detail Page
     */
    private void validateProductDetail() {
        verifyElementDisplayed(prop.getProperty("product_Name"), "Product Detail Page ");
    }

    /**
     * Button Add to Cart
     */
    private void buttonAddToCart() {
        scrollToElement(prop.getProperty("button_addToCart"));


        elementClick(prop.getProperty("button_addToCart"), "Add to cart button");
    }

    /**
     * Navigate to cart
     */
    private void clickOnCartIcon() {
        elementClick(prop.getProperty("cartIcon"), "Cart Icon");
    }

    /**
     * verify Product Detail And Add to cart
     */
    public void verifyProductDetailsAndAddToCart() {
        validateProductDetail();
        buttonAddToCart();
        clickOnCartIcon();
    }

}
