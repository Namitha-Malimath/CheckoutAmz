package utilities;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @author Namitha
 */
public class FetchExcel {

    UtilClass utilClass = new UtilClass();

    /**
     * read data from excel sheet
     *
     * @return - returns data read from excel
     */
    public String readData() {

        String src = utilClass.readConfigFile("PATH") + "/src/main/resources/TestData/Testdata.xlsx";
        FileInputStream fis = null;
        XSSFWorkbook wb = null;
        try {
            fis = new FileInputStream(src);
            wb = new XSSFWorkbook(fis);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        XSSFSheet input_Sheet = wb.getSheet("Input");
        String data = input_Sheet.getRow(1).getCell(1).getStringCellValue();
        System.out.println(data);
        //wb.close();
        return data;
    }


}
