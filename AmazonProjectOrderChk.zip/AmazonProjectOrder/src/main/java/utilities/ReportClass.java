package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

/***
 * @author Namitha
 */
public class ReportClass {

    public ExtentTest test;
    public static ExtentReports extent;

    /**
     * @return Initializes the extent test report
     */
    public ExtentReports startResult() {
        ExtentHtmlReporter reporter = new ExtentHtmlReporter("./Reports/Result.html");
        extent = new ExtentReports();
        extent.attachReporter(reporter);
        // extent.loadConfig(new File("./src/main/resources/extent-config.xml"));
        test = extent.createTest("Amazon order");

        return extent;
    }

    /**
     * ends result
     */
    public void endResult() {

        extent.flush();
    }
}
