package test;

import org.testng.annotations.Test;
import pages.*;
import utilities.UtilClass;

/**
 * @author Namitha
 */
public class ProductCheckout extends UtilClass {

    @Test
    public void TestCase1() {
        LoginPage loginPage = new LoginPage(driver, test);
        loginPage.validateAndSelectSkipLogin();

        HomePage homePage = new HomePage(driver, test);
        homePage.searchAndSelectProduct();

        LocationDetailPage locationDetailPage = new LocationDetailPage(driver, test);
        locationDetailPage.location_details();

        ProductDetailsPage productDetailsPage = new ProductDetailsPage(driver, test);
        productDetailsPage.verifyProductDetailsAndAddToCart();

        CartPage cartPage = new CartPage(driver, test);
        cartPage.cartItem();
    }

    @Test (priority = 0)
    public void login(){
        LoginPage loginPage = new LoginPage(driver, test);
        loginPage.validateAndSelectSkipLogin();
    }

    @Test (priority = 1)
    public void home(){
        HomePage homePage = new HomePage(driver, test);
        homePage.searchAndSelectProduct();
    }

    @Test (priority = 2)
    public void location(){
        LocationDetailPage locationDetailPage = new LocationDetailPage(driver, test);
        locationDetailPage.location_details();
    }

    @Test (priority = 3)
    public void product(){
        ProductDetailsPage productDetailsPage = new ProductDetailsPage(driver, test);
        productDetailsPage.verifyProductDetailsAndAddToCart();
    }

    @Test (priority = 4)
    public void cart(){
        CartPage cartPage = new CartPage(driver, test);
        cartPage.cartItem();
    }
}
