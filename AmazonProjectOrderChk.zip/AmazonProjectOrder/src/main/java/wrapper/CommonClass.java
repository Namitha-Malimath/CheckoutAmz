package wrapper;

import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.testng.Assert;
import utilities.UtilClass;

import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.SECONDS;

/***
 *
 * @author Namitha
 */
public class CommonClass extends UtilClass {

    public void elementClick(String property, String message) {
        AndroidElement element = getLocator(property);
        try {
            waitForElementClickable(element);
            element.click();
            System.out.println(message + " element is clicked");
            reportLog(message + " element is clicked", "PASS");
        } catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
        }
    }

    public void enterText(String property, String message) {
        AndroidElement element = getLocator(property);
        boolean flag = false;
        int count = 1;
        try {
            /*waitForElement();
            element.click();*/
            /* do{*/
            Thread.sleep(5000);
            waitForElement();
            driver.manage().timeouts().implicitlyWait(30, SECONDS);
            //waitForElementClickable(element);
                element.clear();
                element.sendKeys(message);
                flag = true;
                count++;
            reportLog(message + " is entered", "PASS");
            System.out.println(message + "entered");
            /* }while(flag=true || count>=10);*/
        } catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
        }
    }

    public void verifyElementDisplayed(String property, String message) {
        AndroidElement element = getLocator(property);
        try {
            waitForElement();
            element.isDisplayed();
            System.out.println(message + "element is displayed");
            reportLog(message + " element is displayed", "PASS");
        } catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
        }
    }

    public void generateAndClickRandom(String property, String message) {
        int ran_Num = 0, ele_Size = 0;
        Random random = new Random();
        WebElement element = null;

        ele_Size = getElements(property).size();
        ran_Num = random.nextInt(ele_Size);
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            element = getElements(property).get(ran_Num);
            element.click();
            reportLog(message + " random element is clicked", "PASS");
            System.out.println(message);
        } catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
        }
    }

    public void scrollToElement(String property) {
        AndroidElement element = getLocator(property);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "down");
        js.executeScript("mobile: swipe", scrollObject);

    }

    public boolean verifyElement(String property) {
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        boolean present = true;
        try {
            getLocator(property);
            return present;
        } catch (Exception e) {
            present = false;
            e.printStackTrace();
            return present;
        }
    }

    public String getText(String property) {
        AndroidElement element = getLocator(property);
        String text = null;
        try {
            text = element.getText();

        } catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
        }
        return text;
    }

    public void enterTextJavascript(String property, String message) {
        AndroidElement element = getLocator(property);
        JavascriptExecutor jse = driver;
        jse.executeScript("arguments[0].value='" + message + "';", element);

    }
}

